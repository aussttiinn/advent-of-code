from aoc_python.model import Input

input = Input.read(2024, 4)

def main(): 
    print(input)

if __name__ == "__main__": 
    main()
