import os 

class Input:
    BASE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources")

    @classmethod
    def read(cls, year:int, day:int) -> list[str]:
        with open(os.path.join(cls.BASE_DIR, f"{year}_{day}.txt")) as f:
            return [line.strip() for line in f.readlines()]